/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siquieresloteria;

import java.time.DayOfWeek;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static java.time.temporal.TemporalAdjusters.next;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author velalohu
 */
public class Siquieresloteria {

    //si es jueves pal siguiente jueves.(los sorteos es a a noche)
    // trabajar la parte de la fecha en primitiva
    // cuando haces la quiniela se genera 2 veces el menu principal, soluciona eso.
    /**
     */
    public static void menu() {  //metodo que genera el menu
        System.out.println("...................");
        System.out.println("LOTERIAS Y APUESTAS");
        System.out.println("...................");
        System.out.println("1-Primitiva");
        System.out.println("2-Quiniela");
        System.out.println("3-Loteria Nacional");
        System.out.println("0-Salir");
    }

    /**
     *
     * @param oracion
     * @return
     */
    public static String leerCad(String oracion) { // metodo que lee un dato String por teclado
        Scanner sc = new Scanner(System.in);
        System.out.println(oracion);
        String valor = sc.nextLine();
        return valor;
    }

    /**
     *
     * @param oracion
     * @return
     */
    public static int leerint(String oracion) { // metodo que lee un dato Int por teclado
        Scanner sc = new Scanner(System.in);
        System.out.println(oracion);
        int valor = sc.nextInt();
        return valor;
    }

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        LocalDateTime hoy = LocalDateTime.now();
        Scanner sc = new Scanner(System.in);
        Random rnd = new Random();
        double monedero = 0;
        boolean bandera = true;
        while (bandera) { //bucle que repetira el menu mientras bandera sea cierto
            menu();
            String eleccion = leerCad("Elige el juego: "); // elige la opcion de juego por teclado

            switch (eleccion) { // dependiendo de la eleccion elegira una case diferente
                case "1" -> {
                    System.out.println("...................");
                    System.out.println("Elegiste la primitiva");
                    LocalDateTime proxdia = hoy.with(next(DayOfWeek.THURSDAY)); // indica el proximo jueves
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("EEEE dd 'de' MMMM 'de' YYYY"); // le aplica un formato

                    System.out.println("Proximo sorteo: " + dtf.format(proxdia)); //imprime el proximo jueves con ese formato por pantalla

                    String respuesta = "Si";

                    while ("Si".equals(respuesta)) { // bucle para repetir la generacion de la loteria si se lo indicas con "Si"

                        int loteria = 567489;
                        int complementario = 23;
                        int reintegro = 5;

                        System.out.println("Apuesta: " + loteria);
                        System.out.println("Complementario " + complementario + " Reintegro: " + reintegro);
                        monedero = monedero + 1;
                        System.out.println("LLevas un total de " + monedero + " €");
                        respuesta = leerCad("¿Quieres generar otro? (introduce |Si| en ese caso)");

                    }

                }

                case "2" -> {
                    System.out.println("Elegiste la quiniela");
                    LocalDateTime proxdia = hoy.with(next(DayOfWeek.SUNDAY));
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("EEEE dd 'de' MMMM 'de' YYYY");

                    System.out.println("Proximo sorteo: " + dtf.format(proxdia));
                    int apuestas = 0;
                    String repetir = "Si";
                    int contadorapuestas = 0;
                    while ("Si".equals(repetir)) {
                        while (apuestas < 2 || apuestas > 8) {
                            apuestas = leerint("¿Cuantas apuestas quieres realizar (2-8)?");

                            if (apuestas < 2 || apuestas > 8) {
                                System.out.println("Numero de apuestas incorrecto");
                            }
                        }

                        String resultado = "";
                        int contador = 1;
                        while (contador <= apuestas) {
                            String apuesta = "";
                            for (int i = 0; i < 15; i++) {
                                int partido = rnd.nextInt(3);
                                switch (partido) {
                                    case 0:
                                        resultado = "1";
                                        break;
                                    case 1:
                                        resultado = "2";
                                        break;
                                    case 2:
                                        resultado = "X";
                                        break;

                                }
                                apuesta = apuesta + resultado;

                            }

                            System.out.println("apuesta" + contador + ":" + apuesta);

                            contador++;
                            monedero = monedero + 0.5;
                        }

                        System.out.println("LLevas un total de " + monedero + " €");
                        repetir = leerCad("¿Quieres realizar otra quiniela?");
                        apuestas = 0;

                    }
                }
                case "3" -> {
                    System.out.println("Elegiste Loteria Nacional");
                    LocalDateTime proxdia = hoy.with(next(DayOfWeek.SATURDAY));
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("EEEE dd 'de' MMMM 'de' YYYY");

                    System.out.println("Proximo sorteo: " + dtf.format(proxdia));
                    String respuesta = "Si";
                    while ("Si".equals(respuesta)) {
                        String boleto = "";
                        String terminacion = "";
                        while (terminacion.length() != 3) {
                            terminacion = leerCad("Elige las 3 ultimas cifras de tu numero(Si no quieres elegir simplemente pulsa intro): ");
                            if (terminacion.length() == 0) {
                                for (int i = 0; i < 5; i++) {
                                    int aleatorio = rnd.nextInt(9);
                                    boleto = boleto + aleatorio;
                                    terminacion = "123";
                                }
                            } else if (terminacion.length() == 3) {
                                for (int i = 0; i < 2; i++) {
                                    int aleatorio = rnd.nextInt(9);
                                    boleto = boleto + aleatorio;
                                }
                                boleto = boleto + terminacion;
                            } else {
                                System.out.println("ERROR, tienen que ser 3 cifras");
                            }

                        }
                        String serie = "";
                        for (int i = 0; i < 3; i++) {
                            int aleatorio = rnd.nextInt(9);
                            serie = serie + aleatorio;
                        }
                        String fraccion = "";
                        for (int i = 0; i < 2; i++) {
                            int aleatorio = rnd.nextInt(9);
                            fraccion = fraccion + aleatorio;
                        }
                        System.out.println("---------------------------------");
                        System.out.println("|   Numero: " + boleto + "               |");
                        System.out.println("|                               |");
                        System.out.println("|              serie: " + serie + "       |");
                        System.out.println("|                               |");
                        System.out.println("|           fraccion: " + fraccion + "        |");
                        System.out.println("---------------------------------");
                        monedero = monedero + 12;
                        System.out.println("LLevas un total de " + monedero + " €");
                        respuesta = leerCad("¿Quieres generar otro decimo?(Si/No)");
                    }
                }
                case "0" -> {
                    System.out.println("saliendo...");
                    System.out.println("Total a pagar: " + monedero + "€");
                    bandera = false;
                }
                default ->
                    System.out.println("ERROR, introduce una opcion existente");
            }

        }
    }

}
