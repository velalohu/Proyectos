/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package automovi;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hugo
 */
public class prueba {

    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        Automovi coche = new Automovi("657frt", 180, 5.0, 5);
        while (true) {
            System.out.println("¿que quieres hacer?");
            String accion = sc.next();
            if ("arrancar".equals(accion)) {
                try {
                    coche.arrancar();
                } catch (Exception ex) {
                    Logger.getLogger(prueba.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if ("acelerar".equals(accion)) {
                try {
                    System.out.println("¿Que velocidad quieres alcanzar?");
                    int objetivo = sc.nextInt();
                    coche.acelerar(objetivo);
                } catch (Exception ex) {
                    Logger.getLogger(prueba.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if ("repostar".equals(accion)) {
                try {
                    System.out.println("¿Cuantos litros quieres repostar?");
                    int objetivo = sc.nextInt();
                    coche.repostar(objetivo);
                } catch (Exception ex) {
                    Logger.getLogger(prueba.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if ("parar".equals(accion)) {
                try {
                    coche.parar();
                } catch (Exception ex) {
                    Logger.getLogger(prueba.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if ("decelerar".equals(accion)) {
                try {
                    System.out.println("¿A que velocidad quieres reducir?");
                    int objetivo = sc.nextInt();
                    coche.decelerar(objetivo);
                } catch (Exception ex) {
                    Logger.getLogger(prueba.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if ("entrar".equals(accion)) {
                try {
                    coche.entrar();
                } catch (Exception ex) {
                    Logger.getLogger(prueba.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else if ("salir".equals(accion)){
                try {
                    coche.salir();
                } catch (Exception ex) {
                    Logger.getLogger(prueba.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

}