/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package automovi;

import static java.lang.System.exit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hugo
 */
public class Automovi {

    //atributos
    private String Matricula;
    private String Marca;
    private String Modelo;
    private int potencia;
    private double deposito;
    private boolean arrancado;
    private int velocidad;
    private int velocidadMaxima;
    private double capacidadDeposito;
    private int capacidad;
    private int personasActual;

    //constructor
    public Automovi(String Matricula, int velocidadMaxima, double capacidadDeposito, int capacidad) {
        this.Matricula = Matricula;
        this.velocidadMaxima = velocidadMaxima;
        this.capacidadDeposito = capacidadDeposito;
        this.capacidad = capacidad;
        this.deposito = capacidadDeposito;
        this.arrancado = false;
    }

    //metodos
    public String getMatricula() {
        return Matricula;
    }

    public void setMatricula(String Matricula) {
        this.Matricula = Matricula;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public double getDeposito() {
        return deposito;
    }

    public void setDeposito(double deposito) {
        this.deposito = deposito;
    }

    public boolean isArrancado() {
        return arrancado;
    }

    public void setArrancado(boolean arrancado) {
        this.arrancado = arrancado;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public int getVelocidadMaxima() {
        return velocidadMaxima;
    }

    public void setVelocidadMaxima(int velocidadMaxima) {
        this.velocidadMaxima = velocidadMaxima;
    }

    public double getCapacidadDeposito() {
        return capacidadDeposito;
    }

    public void setCapacidadDeposito(double capacidadDeposito) {
        this.capacidadDeposito = capacidadDeposito;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public void arrancar() throws Exception {
        if (personasActual == 0) {
            throw new Exception("El coche esta vacio");
        } else if (deposito == 0) {
            throw new Exception("No te queda gasolina");
        } else if (arrancado == true) {
            throw new Exception("El motor ya estaba encendido");
        } else {
            arrancado = true;
            System.out.println("el motor se encendio");
        }
    }

    public void parar() throws Exception {
        if (velocidad > 0) {
            throw new Exception("No te puedes parar en movimiento");
        } else if (arrancado == false) {
            throw new Exception("El motor ya estaba apagado");
        } else {
            velocidad = 0;
            arrancado = false;
            System.out.println("el motor se apago");
        }
    }

    public void repostar(double litros) throws InterruptedException, Exception {
        if (arrancado == true) {
            throw new Exception("No puedes repostar mientras el motor este encendido");
        } else {
            double objetivo = deposito + litros;
            while (deposito < objetivo && deposito < capacidadDeposito) {
                this.deposito = deposito + 0.5;
                Thread.sleep(200);
                System.out.println("llenando deposito... " + deposito);
            }

            if (deposito >= capacidadDeposito) {
                deposito = capacidadDeposito;
                System.out.println("llenaste el deposito");
            } else {
                System.out.println("ahora tienes " + deposito + "litros");
            }
        }
    }

    public void acelerar(int objetivo) throws InterruptedException, Exception {

        if (arrancado == false) {
            throw new Exception("Antes de ponerte en marcha, arranca el coche");
        } else {
            boolean limite = false;
            int contador = velocidad;
            while (velocidad < objetivo && limite == false && deposito != 0) {
                if (velocidad >= velocidadMaxima) {
                    System.out.println("alcanzaste la velocidad maxima");
                    limite = true;
                } else {
                    contador = contador + 10;
                    velocidad = contador;
                    deposito = deposito - 0.5;
                    Thread.sleep(350);
                    System.out.println("la velocidad actual es: " + velocidad + " km/h" + ", te quedan " + deposito + "litros");

                }
            }
            if (deposito == 0) {
                System.out.println("No te queda gasolina");
                decelerar(0);
                try {
                    parar();
                } catch (Exception ex) {
                    System.out.println(ex.getMessage());
                }
            }
        }

    }

    public void decelerar(int objetivo) throws InterruptedException, Exception {
        if (objetivo < 0) {
            throw new Exception("No puedes reducir a velocidades negativas");
        } else if (arrancado == false) {
            throw new Exception("El coche ya esta parado, no puedes decelerar");
        } else {
            boolean minimo = false;
            int contador = velocidad;
            while (velocidad > objetivo && minimo == false) {
                if (velocidad == 0) {
                    System.out.println("Te paraste");
                    minimo = true;

                } else {
                    contador = contador - 5;
                    velocidad = contador;

                    Thread.sleep(350);
                    System.out.println("la velocidad actual es: " + velocidad + " km/h");

                }
            }
        }
    
}

public void entrar() throws Exception {
        if (personasActual >= capacidad) {
            throw new Exception("No caben mas personas");
        } else if (velocidad > 0) {
            throw new Exception("El coche esta en movimiento no puede entrar gente");

        } else {

            personasActual++;
            System.out.println("Entro una persona, " + "hay un total de " + personasActual + " personas");
        }

    }

    public void salir() throws Exception {
        if (personasActual <= 0) {
            throw new Exception("No quedan personas dentro");
        } else if (velocidad > 0) {
            throw new Exception("El coche esta en marcha no puede salir gente");
        } else {
            personasActual--;
            System.out.println("Salio una persona," + "hay un total de " + personasActual + " personas");
        }
    }

}
